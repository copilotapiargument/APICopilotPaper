package flute.feature.arg;

public class ArgumentUsage {
    public Integer psOccurence;
    public Integer nonPsOccurence;

    public ArgumentUsage(Integer psOccurence, Integer nonPsOccurence) {
        this.psOccurence = psOccurence;
        this.nonPsOccurence = nonPsOccurence;
    }
}
