package flute.feature.arg;

public class Argument {
    public String method;
    public Integer position;

    public Argument(String method, Integer position) {
        this.method = method;
        this.position = position;
    }
}
