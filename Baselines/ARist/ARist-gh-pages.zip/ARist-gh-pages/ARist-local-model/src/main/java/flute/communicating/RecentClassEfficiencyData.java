package flute.communicating;

public class RecentClassEfficiencyData {
    public int fold;
    public int test_id;
    public int totalRecent;
    public int containTarget;
    public String paramTypeKey;
}
