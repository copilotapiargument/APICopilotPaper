package flute.communicating;

public class PublicStaticEfficiencyData {
    public int fold;
    public Integer test_id;
    public Integer total;
    public Integer reduced;
    public int containTargetBeforeReduced;
    public int containTargetAfterReduced;
    public String paramTypeKey;
}
