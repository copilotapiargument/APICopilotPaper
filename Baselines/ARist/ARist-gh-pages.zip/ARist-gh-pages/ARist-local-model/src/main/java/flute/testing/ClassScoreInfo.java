package flute.testing;

import flute.feature.ps.PsClass;

public class ClassScoreInfo extends ScoreInfo{
    public PsClass classCand;
}
