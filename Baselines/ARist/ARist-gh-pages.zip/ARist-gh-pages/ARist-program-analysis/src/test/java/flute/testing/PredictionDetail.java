package flute.testing;

import java.util.List;

public class PredictionDetail {
    public List<String> predictions_lex;
    public List<String> predictions_excode;
    public List<Double> score;
    public Double runtime;
    public Integer test_id;
}
