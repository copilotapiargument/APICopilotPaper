/**
 * 
 */
package flute.tokenizing.excode_data;

public class Constants {

	/**
	 * @param args
	 */
	public synchronized static void main(String[] args) {

	}

	public static final String UNKNOWN_TYPE = "_UNKNOWN_";
}
