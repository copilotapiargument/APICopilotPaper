#Generate JSON schema
[jsonschema2pojo](http://www.jsonschema2pojo.org/)