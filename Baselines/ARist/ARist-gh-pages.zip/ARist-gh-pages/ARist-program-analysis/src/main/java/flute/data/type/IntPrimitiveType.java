package flute.data.type;

public class IntPrimitiveType extends NumPrimitiveType {
    protected static final String KEY = "I";

    @Override
    public String getKey() {
        return KEY;
    }
}
