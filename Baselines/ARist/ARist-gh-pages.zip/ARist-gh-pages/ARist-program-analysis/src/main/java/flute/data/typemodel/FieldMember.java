package flute.data.typemodel;

import org.eclipse.jdt.core.dom.IBinding;

public class FieldMember extends Member {
    public FieldMember(IBinding member) {
        super(member);
    }
}
