package flute.jdtparser.predict.similar;

public enum StatData {
    SHORT_NAME, //name has no more 3 character
    NUMBER_NAME,//name has least one number in character
    LOCAL_NAME,//name is local variable
    SHORT_LOCAL_NAME//short name is variable name
}
