package flute.jdtparser.callsequence.node.ast;

public class ASTCustomNode {
}
