package flute.jdtparser.callsequence.node.cfg;

public class BreakNode extends MinimalNode {
}
