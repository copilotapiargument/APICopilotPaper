package flute.analysis.config;

public class Config extends flute.config.Config {
    public static int NUM_REPO_LIMIT = 1000;
}
