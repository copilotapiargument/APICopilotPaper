package flute.data.constraint;

public class ParserConstant {
    public static final int VARARGS_TRUE_VALUE = 2;
    public static final int FALSE_VALUE = 0;
    public static final int TRUE_VALUE = 1;
    public static final int CAN_BE_CAST_VALUE = 3;
    public static final int IS_ARRAY_VALUE = 4;
}
