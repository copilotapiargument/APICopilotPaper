package flute.jdtparser.statistics.data;

public enum DataType {
    INNER_CLASS_METHOD,
    OTHER_CLASS_METHOD,
    NUM_METHOD_INVOCATION,
}
